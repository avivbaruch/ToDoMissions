import { Component } from "@angular/core";
import { MissionsService } from "../services/missions.service";

@Component({
    selector:'add-mission',
    template:`
        <input type="text"
          style="width:400px; color:red;font-size:24px;"
             (keyup.enter) ="addMission($event.target.value);
             $event.target.value=''"   
          />
    `
})
export class AddMissionComponent
{
    constructor(public service:MissionsService ){

    }

    addMission(missionToAdd:string){
        this.service.addMission(missionToAdd);
    }
}